from __future__ import absolute_import
from __future__ import unicode_literals

from compose.cli.main import main

main()
