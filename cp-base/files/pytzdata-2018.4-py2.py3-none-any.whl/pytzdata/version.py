# -*- coding: utf-8 -*-

VERSION = '2018.4'

OLSON_VERSION = '2018d'
